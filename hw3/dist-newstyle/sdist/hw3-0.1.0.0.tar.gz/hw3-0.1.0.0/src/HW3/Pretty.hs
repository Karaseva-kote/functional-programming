module HW3.Pretty
  ( prettyValue
  ) where

    import Data.Text.Prettyprint.Doc (Doc)
    import Data.Text.Prettyprint.Doc.Render.Terminal (AnsiStyle)
    import HW3.Base
    
    prettyValue :: HiValue -> Doc AnsiStyle
    prettyValue = undefined