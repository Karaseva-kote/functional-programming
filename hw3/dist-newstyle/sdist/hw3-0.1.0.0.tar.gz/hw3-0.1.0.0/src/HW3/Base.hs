module HW3.Base 
  ( HiFun (..)
  , HiValue (..)
  , HiExpr (..)
  , HiError (..)
  ) where

    data HiFun 
      = HiFunDiv
      | HiFunMul
      | HiFunAdd
      | HiFunSub

    data HiValue
      = HiValueNumber Rational
      | HiValueFunction HiFun

    data HiExpr
      = HiExprValue HiValue
      | HiExprApply HiExpr [HiExpr]

    data HiError
      = HiErrorInvalidArgument
      | HiErrorInvalidFunction
      | HiErrorArityMismatch
      | HiErrorDivideByZero