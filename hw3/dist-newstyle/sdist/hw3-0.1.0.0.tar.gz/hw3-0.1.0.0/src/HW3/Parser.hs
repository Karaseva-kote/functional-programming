module HW3.Parser
  ( parse
  ) where

    import HW3.Base
    import Text.Megaparsec.Error (ParseErrorBudle)
    
    parse :: String -> Either (ParseErrorBudle String Void) HiExpr
    parse = undefined